import streamlit as st
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set page configuration
st.set_page_config(
    page_title="Diabetes Prediction App",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Clean, professional styling
st.markdown("""
<style>
    /* Main theme colors */
    :root {
        --primary: #2E86AB;
        --secondary: #A23B72;
        --success: #27AE60;
        --warning: #F39C12;
        --danger: #E74C3C;
        --light: #F8F9FA;
        --dark: #2C3E50;
    }
    
    .main-header {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: white;
        padding: 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .prediction-card {
        background: white;
        border-radius: 15px;
        padding: 2rem;
        margin: 1rem 0;
        border-left: 5px solid var(--primary);
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        transition: transform 0.2s ease;
    }
    
    .prediction-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.12);
    }
    
    .feature-card {
        background: var(--light);
        border-radius: 10px;
        padding: 1.5rem;
        margin: 0.5rem 0;
        border: 1px solid #E0E0E0;
    }
    
    .risk-low {
        border-left: 5px solid var(--success);
    }
    
    .risk-medium {
        border-left: 5px solid var(--warning);
    }
    
    .risk-high {
        border-left: 5px solid var(--danger);
    }
    
    .stButton button {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: white;
        border: none;
        border-radius: 8px;
        padding: 12px 30px;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s ease;
        width: 100%;
    }
    
    .stButton button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(46, 134, 171, 0.4);
    }
    
    .metric-container {
        background: white;
        border-radius: 10px;
        padding: 1rem;
        margin: 0.5rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }
    
    .sidebar .sidebar-content {
        background: var(--light);
    }
</style>
""", unsafe_allow_html=True)

# Load the model and scaler
@st.cache_resource
def load_model():
    with open('diabetes_model.pkl', 'rb') as file:
        model = pickle.load(file)
    with open('scaler.pkl', 'rb') as file:
        scaler = pickle.load(file)
    return model, scaler

model, scaler = load_model()

# App header
st.markdown("""
<div class="main-header">
    <h1>🏥 Diabetes Prediction System</h1>
    <p style="font-size: 1.2rem; margin: 0; opacity: 0.9;">
    Advanced machine learning model to assess diabetes risk based on health parameters
    </p>
</div>
""", unsafe_allow_html=True)

# Sidebar for user input
st.sidebar.markdown("""
<div style="text-align: center; margin-bottom: 2rem;">
    <h2>📊 Patient Information</h2>
    <p style="color: #666; font-size: 0.9rem;">Enter health metrics for prediction</p>
</div>
""", unsafe_allow_html=True)

def user_input_features():
    col1, col2 = st.sidebar.columns(2)
    
    with col1:
        st.markdown("<div class='feature-card'>", unsafe_allow_html=True)
        pregnancies = st.number_input('**Pregnancies**', 0, 17, 1, 
                                    help="Number of times pregnant")
        glucose = st.number_input('**Glucose (mg/dL)**', 0, 200, 120,
                                help="Plasma glucose concentration")
        blood_pressure = st.number_input('**Blood Pressure**', 0, 122, 70,
                                       help="Diastolic blood pressure (mm Hg)")
        skin_thickness = st.number_input('**Skin Thickness**', 0, 99, 20,
                                       help="Triceps skin fold thickness (mm)")
        st.markdown("</div>", unsafe_allow_html=True)
    
    with col2:
        st.markdown("<div class='feature-card'>", unsafe_allow_html=True)
        insulin = st.number_input('**Insulin Level**', 0, 846, 79,
                                help="2-Hour serum insulin (mu U/ml)")
        bmi = st.number_input('**BMI**', 0.0, 67.1, 25.0, step=0.1,
                            help="Body mass index")
        diabetes_pedigree = st.number_input('**Diabetes Pedigree**', 0.08, 2.42, 0.5, step=0.01,
                                          help="Diabetes pedigree function")
        age = st.number_input('**Age**', 21, 81, 30,
                            help="Age in years")
        st.markdown("</div>", unsafe_allow_html=True)
    
    data = {
        'Pregnancies': pregnancies,
        'Glucose': glucose,
        'BloodPressure': blood_pressure,
        'SkinThickness': skin_thickness,
        'Insulin': insulin,
        'BMI': bmi,
        'DiabetesPedigreeFunction': diabetes_pedigree,
        'Age': age
    }
    
    return pd.DataFrame(data, index=[0])

# Get user input
input_df = user_input_features()

# Main content
col1, col2 = st.columns([2, 1])

with col1:
    st.markdown("<div class='prediction-card'>", unsafe_allow_html=True)
    st.subheader("📋 Patient Data Summary")
    
    # Display input data in a nice format
    display_data = input_df.T.reset_index()
    display_data.columns = ['Health Parameter', 'Current Value']
    
    # Add normal ranges for context
    normal_ranges = {
        'Glucose': '< 140 mg/dL',
        'BloodPressure': '< 80 mm Hg',
        'BMI': '18.5 - 24.9',
        'Insulin': '< 25 μU/mL'
    }
    
    display_data['Normal Range'] = display_data['Health Parameter'].map(normal_ranges)
    display_data['Normal Range'] = display_data['Normal Range'].fillna('-')
    
    st.dataframe(
        display_data,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Health Parameter": st.column_config.TextColumn(width="medium"),
            "Current Value": st.column_config.NumberColumn(width="small"),
            "Normal Range": st.column_config.TextColumn(width="medium")
        }
    )
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Feature importance
    st.markdown("<div class='prediction-card'>", unsafe_allow_html=True)
    st.subheader("📈 Feature Importance")
    
    feature_importance = pd.DataFrame({
        'feature': input_df.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=True)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(feature_importance['feature'], feature_importance['importance'], 
                   color=['#2E86AB', '#A23B72', '#27AE60', '#F39C12', '#E74C3C', '#8E44AD', '#16A085', '#2980B9'])
    ax.set_xlabel('Importance Score', fontweight='bold')
    ax.set_title('Feature Importance in Diabetes Prediction', fontweight='bold', pad=20)
    ax.grid(axis='x', alpha=0.3)
    
    # Add value labels
    for bar in bars:
        width = bar.get_width()
        ax.text(width + 0.01, bar.get_y() + bar.get_height()/2, 
                f'{width:.3f}', ha='left', va='center', fontweight='bold')
    
    st.pyplot(fig)
    st.markdown("</div>", unsafe_allow_html=True)

with col2:
    st.markdown("<div class='prediction-card'>", unsafe_allow_html=True)
    st.subheader("🎯 Risk Prediction")
    
    if st.button('**🔍 Analyze Diabetes Risk**', use_container_width=True):
        # Scale the input
        input_scaled = scaler.transform(input_df)
        
        # Make prediction
        prediction = model.predict(input_scaled)
        prediction_proba = model.predict_proba(input_scaled)
        
        probability = prediction_proba[0][1] * 100
        
        # Determine risk level
        if probability < 30:
            risk_class = "risk-low"
            risk_text = "Low Risk"
            emoji = "✅"
            color = "green"
        elif probability < 70:
            risk_class = "risk-medium"
            risk_text = "Medium Risk"
            emoji = "⚠️"
            color = "orange"
        else:
            risk_class = "risk-high"
            risk_text = "High Risk"
            emoji = "🩺"
            color = "red"
        
        st.markdown(f"<div class='prediction-card {risk_class}'>", unsafe_allow_html=True)
        
        # Display result
        col_a, col_b = st.columns([1, 2])
        with col_a:
            st.markdown(f"<h1 style='color: {color}; font-size: 3rem; margin: 0;'>{emoji}</h1>", unsafe_allow_html=True)
        with col_b:
            st.markdown(f"<h2 style='color: {color}; margin: 0;'>{risk_text}</h2>", unsafe_allow_html=True)
            st.metric("Probability", f"{probability:.1f}%")
        
        # Progress bar
        st.progress(int(probability) / 100)
        
        # Recommendations based on risk level
        if risk_text == "Low Risk":
            st.success("""
            **🎉 Excellent! Keep up the good work:**
            • Continue healthy lifestyle habits
            • Regular annual check-ups
            • Balanced diet with variety
            • Maintain physical activity
            """)
        elif risk_text == "Medium Risk":
            st.warning("""
            **📋 Recommended Actions:**
            • Consult healthcare provider
            • Monitor blood sugar quarterly
            • Improve diet and exercise
            • Reduce sugar intake
            • Regular health screenings
            """)
        else:
            st.error("""
            **🚨 Immediate Attention Needed:**
            • Consult doctor immediately
            • Regular glucose monitoring
            • Strict dietary control
            • Medication if prescribed
            • Comprehensive care plan
            """)
        
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.info("👆 Click the button above to analyze diabetes risk based on the entered health metrics.")
    
    st.markdown("</div>", unsafe_allow_html=True)

# Risk factors analysis
st.markdown("<div class='prediction-card'>", unsafe_allow_html=True)
st.subheader("🔍 Risk Factor Analysis")

risk_col1, risk_col2, risk_col3, risk_col4 = st.columns(4)

with risk_col1:
    glucose_status = "High" if input_df['Glucose'].values[0] > 140 else "Normal"
    status_color = "red" if glucose_status == "High" else "green"
    st.metric("Glucose", f"{input_df['Glucose'].values[0]} mg/dL", delta=glucose_status, delta_color="inverse" if glucose_status == "High" else "normal")

with risk_col2:
    bmi_status = "High" if input_df['BMI'].values[0] > 30 else "Normal" if input_df['BMI'].values[0] > 25 else "Low"
    status_color = "red" if bmi_status == "High" else "orange" if bmi_status == "Normal" else "green"
    st.metric("BMI", f"{input_df['BMI'].values[0]:.1f}", delta=bmi_status, delta_color="inverse" if bmi_status == "High" else "normal")

with risk_col3:
    bp_status = "High" if input_df['BloodPressure'].values[0] > 80 else "Normal"
    st.metric("Blood Pressure", f"{input_df['BloodPressure'].values[0]} mm Hg", delta=bp_status, delta_color="inverse" if bp_status == "High" else "normal")

with risk_col4:
    age_status = "Higher Risk" if input_df['Age'].values[0] > 45 else "Normal"
    st.metric("Age", f"{input_df['Age'].values[0]} years", delta=age_status, delta_color="inverse" if age_status == "Higher Risk" else "normal")
st.markdown("</div>", unsafe_allow_html=True)

# Quick tips section
st.markdown("<div class='prediction-card'>", unsafe_allow_html=True)
st.subheader("💡 Health Tips & Information")

tip_col1, tip_col2, tip_col3 = st.columns(3)

with tip_col1:
    st.markdown("""
    **🍎 Diet Recommendations**
    - Choose whole grains over refined carbs
    - Include plenty of vegetables
    - Limit sugar and processed foods
    - Control portion sizes
    """)

with tip_col2:
    st.markdown("""
    **🏃‍♂️ Lifestyle Tips**
    - 30 minutes exercise daily
    - Maintain healthy weight
    - Regular sleep patterns
    - Stress management
    """)

with tip_col3:
    st.markdown("""
    **🩺 Medical Advice**
    - Regular health check-ups
    - Monitor key metrics
    - Follow medical advice
    - Stay informed
    """)
st.markdown("</div>", unsafe_allow_html=True)

# Footer
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center; color: #666; padding: 2rem;'>
        <p><strong></strong> Made My DS Students Under Guidance of Prof. S.V. Chaudhari Sir</p>
        <p></p>
    </div>
    """,
    unsafe_allow_html=True
)

