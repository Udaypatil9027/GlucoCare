import pickle
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# Load and preprocess the data (same as before)
df = pd.read_csv('diabetes.csv')

# Data preprocessing
columns_to_clean = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
df_clean = df.copy()

for column in columns_to_clean:
    df_clean[column] = df_clean[column].replace(0, np.nan)
    df_clean[column].fillna(df_clean[column].median(), inplace=True)

# Prepare features and target
X = df_clean.drop('Outcome', axis=1)
y = df_clean['Outcome']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# Train the model
rf_model = RandomForestClassifier(
    n_estimators=100,
    random_state=42,
    max_depth=10,
    min_samples_split=5,
    min_samples_leaf=2
)
rf_model.fit(X_train_scaled, y_train)

# Save the model and scaler to pickle files
with open('diabetes_model.pkl', 'wb') as model_file:
    pickle.dump(rf_model, model_file)

with open('scaler.pkl', 'wb') as scaler_file:
    pickle.dump(scaler, scaler_file)

print("Model and scaler saved successfully!")
print("Files created: diabetes_model.pkl, scaler.pkl")